<?php $__env->startSection('content'); ?>
<!-- Cart Start -->
<div class="container-fluid">
    
    <button class="btn mb-3" style="background-color:rgba(47, 224, 44, 0.933); margin-left: 285px;">
        <a class=" text-decoration-none text-white" href="<?php echo e(route('user#home')); ?>"><i class="fa-solid fa-circle-arrow-left me-2"></i>Back</a>
    </button>
    <div class="row px-xl-5">
        <div class="col-lg-8 offset-2 table-responsive mb-5" style="height: 450px">
            <table class="table table-light table-borderless table-hover text-center mb-0" id="dataTable">
                <thead class="thead-dark position-sticky top-0">
                    <tr>
                        <th>name</th>
                        <th>order code</th>
                        <th>order date</th>
                        <th>amount</th>
                        <th>status</th>
                    </tr>
                </thead>
                <tbody class="align-middle">
                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($o->user_name); ?></td>
                            <td><?php echo e($o->order_code); ?></td>
                            <td><?php echo e($o->created_at->format('F-j-Y h:m A')); ?></td>
                            <td><?php echo e($o->total_price); ?></td>
                            <td>
                                <?php if($o->status == 0): ?>
                                    <span class="text-warning"><i class="fa-sharp fa-regular fa-clock me-2"></i>Pending</span>
                                <?php elseif($o->status == 1): ?>
                                    <span class="text-success"><i class="fa-solid fa-check me-2"></i>Success</span>
                                <?php elseif($o->status == 2): ?>
                                    <span class="text-danger"><i class="fa-solid fa-xmark me-2"></i>Reject</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="mt-3">
                
            </div>
        </div>
    </div>
</div>
<!-- Cart End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pizza_order_system\resources\views/user/main/history.blade.php ENDPATH**/ ?>