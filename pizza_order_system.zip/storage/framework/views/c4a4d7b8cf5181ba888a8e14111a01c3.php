<?php $__env->startSection('title' , 'Admin List Page'); ?>

<?php $__env->startSection('content'); ?>
    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <div class="table-data__tool d-flex align-items-center" >
                        <div class="table-data__tool-left d-flex" style="width: 100px !improtant">
                            <div class="overview-wrap me-3" >
                                <h2 class="title-1">Order List</h2>
                            </div>

                            
                            <div style="width: 50px">
                                <div style="background-color:rgba(47, 224, 44, 0.933); width:100%;" class="text-center py-1 rounded text-white"><i class="fa-solid fa-chart-simple"> - <?php echo e(count($order)); ?></i></div>
                            </div>
                        </div>
                        <div class="mt-3">
                            <form action="<?php echo e(route('order#changeList')); ?>" method="get">
                                <?php echo csrf_field(); ?>
                                <div class="d-flex form-group">
                                    <label class="me-2 mt-1">Order Status</label>
                                    <div class="d-flex">
                                        <select name="orderStatus" class="form-control">
                                            <option value="all" <?php if(request('orderStatus') == 'all'): ?> selected <?php endif; ?>>All</option>
                                            <option value="0" <?php if(request('orderStatus') == '0'): ?> selected <?php endif; ?>>Pending</option>
                                            <option value="1" <?php if(request('orderStatus') == '1'): ?> selected <?php endif; ?>>Success</option>
                                            <option value="2" <?php if(request('orderStatus') == '2'): ?> selected <?php endif; ?>>Reject</option>
                                        </select>
                                        <button type="submit" class="btn text-white" style="background-color:rgba(47, 224, 44, 0.933);"><i class="fa-solid fa-magnifying-glass"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    
                    <div class="col-3 offset-9 bg-white rounded p-1 mb-3">
                        <form action="<?php echo e(route('order#list')); ?>" method="get" class="d-flex">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="searchKey" class="form-control" placeholder="Search..." value="<?php echo e(request('searchKey')); ?>">
                            <button type="submit" style="background-color:rgba(47, 224, 44, 0.933);" class="btn text-white"><i class="fa-solid fa-magnifying-glass"></i></button>
                        </form>
                    </div>



                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2">
                            <thead>
                                <tr>
                                    <th>user id</th>
                                    <th>user name</th>
                                    <th>order code</th>
                                    <th>amount</th>
                                    <th>order date</th>
                                    <th>status</th>
                                </tr>
                            </thead>

                            <tbody id="dataList">
                                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="tr-shadow">
                                        <input type="hidden" class="orderId" value="<?php echo e($o->order_id); ?>">
                                        <td class="col-2"><?php echo e($o->user_id); ?></td>
                                        <td class="col-2"><?php echo e($o->user_name); ?></></td>
                                        <td class="col-2">
                                            <a class=" text-decoration-none" href="<?php echo e(route('order#listInfo' , $o->order_code)); ?>"><?php echo e($o->order_code); ?></a>
                                        </td>
                                        <td class="col-2"><?php echo e($o->total_price); ?></td>
                                        <td class="col-2"><?php echo e($o->created_at->format('F-j-Y h:m A')); ?></td>
                                        <td class="col-2">
                                            <select name="status" class="form-control statusChange">
                                                <option value="0" <?php if($o->status == 0): ?> selected <?php endif; ?>>Pending</option>
                                                <option value="1" <?php if($o->status == 1): ?> selected <?php endif; ?>>Success</option>
                                                <option value="2" <?php if($o->status == 2): ?> selected <?php endif; ?>>Reject</option>
                                            </select>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="mt-2 shadow pl-3">
                            
                            
                        </div>
                    </div>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptSource'); ?>
    <script>
        $(document).ready(function () {
            // SORT WITH AJAX ORDER LIST
            // $('#status').change(function () {
            //     $status = '';
            //     $status = $('#status').val();

            //     $.ajax({
            //         type : 'get' ,
            //         url : 'http://localhost:8000/order/ajax/list' ,
            //         data : { 'status' : $status } ,
            //         dataType : 'json' ,
            //         success : function (response) {
            //             $list = "";
            //             for (let $i = 0; $i < response.length; $i++) {

            //                 $months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
            //                 $dbDate = new Date (response[$i].created_at);
            //                 $finalDate = $months[$dbDate.getMonth()] +'-'+ $dbDate.getDate()+'-'+ $dbDate.getFullYear();

            //                 if(response[$i].status == 0)  {
            //                     $statusMessage = `
            //                         <select name="status" class="form-control">
            //                             <option value="0" selected>Pending</option>
            //                             <option value="1" >Success</option>
            //                             <option value="2" >Reject</option>
            //                         </select> `;

            //                 }else if (response[$i].status == 1) {
            //                     $statusMessage = `
            //                         <select name="status" class="form-control">
            //                             <option value="0" >Pending</option>
            //                             <option value="1" selected>Success</option>
            //                             <option value="2" >Reject</option>
            //                         </select> `;

            //                 }else if(response[$i].status == 2) {
            //                     $statusMessage = `
            //                         <select name="status" class="form-control">
            //                             <option value="0" >Pending</option>
            //                             <option value="1" >Success</option>
            //                             <option value="2" selected>Reject</option>
            //                         </select> `;
            //                 }

            //                 $list += `
            //                 <tr class="tr-shadow">
            //                             <td class="col-2">${response[$i].user_id}</td>
            //                             <td class="col-2">${response[$i].user_name}</></td>
            //                             <td class="col-2">${response[$i].order_code}</td>
            //                             <td class="col-2">${response[$i].total_price}</td>
            //                             <td class="col-2">${$finalDate}</td>
            //                             <td class="col-2">${$statusMessage}</td>
            //                         </tr>`;
            //             }
            //             $('#dataList').html($list);
            //         }
            //     });
            // });

            // CHANGE STATUS
            $('.statusChange').change(function () {
                $currentStatus = $(this).val() ;
                $parentNode = $(this).parents('tbody tr');
                $orderId = $parentNode.find('.orderId').val();

                $data = {
                    'status' : $currentStatus ,
                    'orderId' : $orderId
                };

                $.ajax({
                    type : 'get' ,
                    url : 'http://localhost:8000/order/ajax/change/status' ,
                    data : $data,
                    dataType : 'json' ,
                    success : function (response) {
                        console.log('success...');
                    }
                })
            })

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pizza_order_system\resources\views/admin/order/list.blade.php ENDPATH**/ ?>