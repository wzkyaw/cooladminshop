<?php $__env->startSection('title' , 'Admin List Page'); ?>

<?php $__env->startSection('content'); ?>
    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <div class="table-data__tool">
                        <div class="table-data__tool-left">
                            <div class="overview-wrap">
                                <h2 class="title-1">Category List</h2>

                            </div>
                        </div>
                        <div class="table-data__tool-right">
                            <a href="<?php echo e(route('category#createPage')); ?>">
                                <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                    <i class="zmdi zmdi-plus"></i>add category
                                </button>
                            </a>
                            <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                CSV download
                            </button>
                        </div>
                    </div>

                    
                    <div class="col-1 offset-11 mb-4">
                        <div style="background-color:rgba(47, 224, 44, 0.933);" class=" text-center py-1 rounded text-white"><i class="fa-solid fa-chart-simple"> - <?php echo e($categories->total()); ?></i></div>
                    </div>

                    
                    <div class="col-3 offset-9 bg-white rounded p-1">
                        <form action="<?php echo e(route('category#list')); ?>" method="get" class="d-flex">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="searchKey" class="form-control" placeholder="Search..." value="<?php echo e(request('searchKey')); ?>">
                            <button type="submit" class="btn btn-dark text-white"><i class="fa-solid fa-magnifying-glass"></i></button>
                        </form>
                    </div>

                    
                    <?php if(session('createCategorySuccess')): ?>
                        <div class="col-6 offset-6 my-4">
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="fa-solid fa-check"></i>  <?php echo e(session('createCategorySuccess')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(session('deleteCategorySuccess')): ?>
                        <div class="col-6 offset-6 my-4">
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <i class="fa-solid fa-check"></i>  <?php echo e(session('deleteCategorySuccess')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(session('updateCategorySuccess')): ?>
                        <div class="col-6 offset-6 my-4">
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="fa-solid fa-check"></i>  <?php echo e(session('updateCategorySuccess')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if(count($categories) != 0): ?>
                        <div class="table-responsive table-responsive-data2">
                            <table class="table table-data2">
                                <thead>
                                    <tr>
                                        <th>category_id</th>
                                        <th>name</th>
                                        <th>created_at</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="tr-shadow">
                                            <td><?php echo e($category->category_id); ?></td>
                                            <td>
                                                <span><?php echo e($category->name); ?></span>
                                            </td>
                                            <td><?php echo e($category->created_at->format('j-F-Y h:m A')); ?></td>
                                            <td>
                                                <div class="table-data-feature">
                                                    
                                                    <a href="<?php echo e(route('category#edit' , $category->category_id)); ?>">
                                                        <button class="item" data-toggle="tooltip" data-placement="top" title="edit">
                                                            <i class="fa-solid fa-pen-to-square"></i>
                                                        </button>
                                                    </a>
                                                    <a href="<?php echo e(route('category#delete' , $category->category_id)); ?>" class="mr-1">
                                                        <button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                            <i class="fa-solid fa-trash"></i>
                                                        </button>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="mt-2 shadow pl-3">
                                
                                <?php echo e($categories->appends(request()->query())->links()); ?>

                            </div>
                        </div>
                    <?php else: ?>
                        <h4 class="text-secondary text-center mt-5">There is no data to show!</h4>
                    <?php endif; ?>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pizza_order_system\resources\views/admin/category/list.blade.php ENDPATH**/ ?>