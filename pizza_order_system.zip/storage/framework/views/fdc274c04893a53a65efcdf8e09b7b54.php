<?php $__env->startSection('title', 'Admin List Page'); ?>

<?php $__env->startSection('content'); ?>
    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-lg-10 offset-1">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title mt-3 mb-5">
                                <h3 class="text-center title-2">Account Info...</h3>
                            </div>

                            <div class="row">
                                <div class="col-3 offset-3 shadow-sm text-center">
                                    <?php if(Auth::user()->image == null): ?>
                                        <?php if(Auth::user()->gender == 'male'): ?>
                                            <img src="<?php echo e(asset('image/default_user_profile.jpg')); ?>" class=" rounded-circle">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('image/female_default.png')); ?>" class=" rounded-circle">
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('storage/'.Auth::user()->image)); ?>" alt="John Doe" />
                                    <?php endif; ?>
                                </div>
                                <div class="col-5 mt-2 ms-4">
                                    <span class="my-2 d-block"><i class="fa-solid fa-user-pen me-2"></i><?php echo e(Auth::user()->name); ?></span>
                                    <span class="my-2 d-block"><i class="fa-solid fa-envelope me-2"></i><?php echo e(Auth::user()->email); ?></span>
                                    <span class="my-2 d-block"><i class="fa-solid fa-phone me-2"></i><?php echo e(Auth::user()->phone); ?></span>
                                    <span class="my-2 d-block"><i class="fa-solid fa-map-location-dot me-2"></i><?php echo e(Auth::user()->address); ?></span>
                                    <span class="my-2 d-block"><i class="fa-solid fa-user-clock me-2"></i><?php echo e(Auth::user()->created_at->format('j-F-Y h:m A')); ?></span>
                                    <span class="my-2 d-block"><i class="fa-solid fa-user-pen me-2"></i><?php echo e(Auth::user()->gender); ?></span>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-4 offset-5 text-center mt-5 mb-3">
                                    <a href="<?php echo e(route('admin#edit')); ?>">
                                        <button class="btn btn-dark text-white">
                                            <i class="fa-solid fa-pen-to-square"></i>Edit Profile
                                        </button>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pizza_order_system\resources\views/admin/account/details.blade.php ENDPATH**/ ?>