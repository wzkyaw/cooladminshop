<?php $__env->startSection('title' , 'Admin List Page'); ?>

<?php $__env->startSection('content'); ?>
    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">
                    
                    <button class="btn mb-3" style="background-color:rgba(47, 224, 44, 0.933); ">
                        <a class=" text-decoration-none text-white" href="<?php echo e(route('order#list')); ?>"><i class="fa-solid fa-circle-arrow mb-3-left me-2"></i>Back</a>
                    </button>

                    
                    <div class="row col-5">
                        <div class="card mt-4">
                            <div class="card-body mb-2 mt-2  d-flex align-items-center" style="border-bottom: 1px solid rgb(216, 215, 215)">
                                <i class="fa-solid fa-receipt me-2"></i><h3 class="me-3">Order Info</h3> <small class="text-danger"> ( Included Delivery Charges! )</small>
                            </div>
                            <div class="card-body">
                                <div class="row mb-3">
                                    <div class="col"><i class="me-2 fa-solid fa-user"></i>Customer Name</div>
                                    <div class="col"><?php echo e(strtoupper($orderList[0]->user_name)); ?></div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col"><i class="me-2 fa-solid fa-barcode"></i>Order Code</div>
                                    <div class="col"><?php echo e($orderList[0]->order_code); ?></div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col"><i class="me-2 fa-solid fa-clock"></i>Order Date</div>
                                    <div class="col"><?php echo e($orderList[0]->created_at->format('F-j-Y')); ?></div>
                                </div>
                                <div class="row">
                                    <div class="col"><i class="fa-solid fa-dollar-sign me-3"></i>Total</div>
                                    <div class="col"><?php echo e($orderData->total_price); ?> Kyats</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- DATA TABLE -->
                    <div class="table-data__tool" >
                        <div class="table-data__tool-left d-flex" style="width: 100px !improtant">
                            <div class="overview-wrap me-3" >
                                <h2 class="title-1">Order List</h2>
                            </div>

                            
                            <div style="width: 50px">
                                <div style="background-color:rgba(47, 224, 44, 0.933); width:100%;" class="text-center py-1 rounded text-white"><i class="fa-solid fa-chart-simple"> -<?php echo e(count($orderList)); ?></i></div>
                            </div>
                        </div>
                    </div>

                    
                    

                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>order id</th>
                                    <th>product name</th>
                                    <th>product image</th>
                                    <th>quantity</th>
                                    <th>amount</th>
                                    <th>order date</th>
                                    <th></th>
                                </tr>
                            </thead>

                            <tbody id="dataList">
                                <?php $__currentLoopData = $orderList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="tr-shadow">
                                        <td></td>
                                        <td><?php echo e($o->id); ?></td>
                                        <td><?php echo e($o->product_name); ?></td>
                                        <td><img class=" img-thumbnail" style="height: 100px" src="<?php echo e(asset('storage/'.$o->product_image)); ?>"></td>
                                        <td><?php echo e($o->qty); ?></td>
                                        <td><?php echo e($o->total); ?></td>
                                        <td><?php echo e($o->created_at->format('F-j-y')); ?></td>
                                        <td></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="mt-2 shadow pl-3">
                            
                            
                        </div>
                    </div>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pizza_order_system\resources\views/admin/order/productList.blade.php ENDPATH**/ ?>