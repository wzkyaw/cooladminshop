<?php $__env->startSection('title' , 'Admin List Page'); ?>

<?php $__env->startSection('content'); ?>
    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <div class="table-data__tool d-flex align-items-center" >
                        <div class="table-data__tool-left d-flex" style="width: 100px !improtant">
                            <div class="overview-wrap me-3" >
                                <h2 class="title-1">Contact List</h2>
                            </div>

                            
                            <div style="width: 50px">
                                <div style="background-color:rgba(47, 224, 44, 0.933); width:100%;" class="text-center py-1 rounded text-white"><i class="fa-solid fa-chart-simple"> - <?php echo e(count($contactData)); ?></i></div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-3 offset-9 bg-white rounded p-1 mb-3">
                        <form action="<?php echo e(route('admin#contactListPage')); ?>" method="get" class="d-flex">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="searchKey" class="form-control" placeholder="Search..." value="<?php echo e(request('searchKey')); ?>">
                            <button type="submit" style="background-color:rgba(47, 224, 44, 0.933);" class="btn text-white"><i class="fa-solid fa-magnifying-glass"></i></button>
                        </form>
                    </div>

                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2">
                            <thead>
                                <tr>
                                    <th>image</th>
                                    <th>userid</th>
                                    <th>name</th>
                                    <th>email</th>
                                    <th>subject</th>
                                    <th>message</th>
                                    <th>gender</th>
                                </tr>
                            </thead>

                            <tbody id="dataList">
                                <?php $__currentLoopData = $contactData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="tr-shadow">
                                        <td>
                                            <?php if($c->image == null): ?>
                                                <?php if($c->user_gender == 'male'): ?>
                                                    <img src="<?php echo e(asset('image/default_user_profile.jpg')); ?>" style="height: 80px; width: 100px" class=" shadow rounded-circle">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('image/female_default.png')); ?>" style="height: 80px; width: 100px" class="shadow rounded-circle">
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('storage/'.$c->user_image)); ?>" style="height: 80px; width: 100px" class="shadow rounded-circle" alt="John Doe" />
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($c->user_id); ?></td>
                                        <td><?php echo e($c->name); ?></td>
                                        <td><?php echo e($c->email); ?></td>
                                        <td><?php echo e($c->subject); ?></td>
                                        <td><?php echo e($c->message); ?></td>
                                        <td><?php echo e($c->user_gender); ?></td>
                                        <td>
                                            <div class="table-data-feature">
                                                <a href="<?php echo e(route('admin#contactEditPage' , $c->user_id)); ?>">
                                                    <button class="item me-1" data-toggle="tooltip" data-placement="top" title="Edit">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </button>
                                                </a>
                                                <a href="<?php echo e(route('admin#contactDelete' , $c->contact_id)); ?>" class="mr-1">
                                                    <button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                        <i class="fa-solid fa-trash"></i>
                                                    </button>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="mt-2 shadow pl-3">
                            <?php echo e($contactData->links()); ?>

                            
                        </div>
                    </div>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pizza_order_system\resources\views/admin/contact/list.blade.php ENDPATH**/ ?>