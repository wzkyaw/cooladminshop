<?php $__env->startSection('title' , 'Admin List Page'); ?>

<?php $__env->startSection('content'); ?>
    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <div class="table-data__tool d-flex align-items-center" >
                        <div class="table-data__tool-left d-flex" style="width: 100px !improtant">
                            <div class="overview-wrap me-3" >
                                <h2 class="title-1">User List</h2>
                            </div>

                            
                            <div style="width: 50px">
                                <div style="background-color:rgba(47, 224, 44, 0.933); width:100%;" class="text-center py-1 rounded text-white"><i class="fa-solid fa-chart-simple"> - <?php echo e(count($user)); ?></i></div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-3 offset-9 bg-white rounded p-1 mb-3">
                        <form action="<?php echo e(route('user#list')); ?>" method="get" class="d-flex">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="searchKey" class="form-control" placeholder="Search..." value="<?php echo e(request('searchKey')); ?>">
                            <button type="submit" style="background-color:rgba(47, 224, 44, 0.933);" class="btn text-white"><i class="fa-solid fa-magnifying-glass"></i></button>
                        </form>
                    </div>

                    <div class="table-responsive table-responsive-data2">
                        <table class="table table-data2">
                            <thead>
                                <tr>
                                    <th>image</th>
                                    <th>id</th>
                                    <th>name</th>
                                    <th>email</th>
                                    <th>phone</th>
                                    <th>address</th>
                                    <th>gender</th>
                                    <th>role</th>
                                </tr>
                            </thead>

                            <tbody id="dataList">
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="tr-shadow">
                                        <td>
                                            <?php if($u->image == null): ?>
                                                <?php if($u->gender == 'male'): ?>
                                                    <img src="<?php echo e(asset('image/default_user_profile.jpg')); ?>" style="height: 100px" class=" rounded-circle">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('image/female_default.png')); ?>" style="height: 100px" class=" rounded-circle">
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('storage/'.$u->image)); ?>" style="height: 100px" class="rounded-circle" alt="John Doe" />
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($u->id); ?> <input type="hidden" id="userId" value="<?php echo e($u->id); ?>"></td>
                                        <td><?php echo e($u->name); ?></td>
                                        <td><?php echo e($u->email); ?></td>
                                        <td><?php echo e($u->phone); ?></td>
                                        <td><?php echo e($u->address); ?></td>
                                        <td><?php echo e($u->gender); ?></td>
                                        <td>
                                            <select name="status" class="statusChange" class="form-control">
                                                <option value="user" <?php if($u->role == 'user'): ?> selected <?php endif; ?>>User</option>
                                                <option value="admin" <?php if($u->role == 'admin'): ?> selected <?php endif; ?>>Admin</option>
                                            </select>
                                        </td>
                                        <td>
                                            <div class="table-data-feature">
                                                <a href="<?php echo e(route('admin#userListEdit' , $u->id)); ?>">
                                                    <button class="item me-1" data-toggle="tooltip" data-placement="top" title="Edit">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </button>
                                                </a>
                                                <a href="<?php echo e(route('admin#userListDelete' , $u->id)); ?>" class="mr-1">
                                                    <button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                        <i class="fa-solid fa-trash"></i>
                                                    </button>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="mt-2 shadow pl-3">
                            <?php echo e($user->links()); ?>

                            
                        </div>
                    </div>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptSource'); ?>
    <script>
        $(document).ready(function () {
            // CHANGE STATUS
            $('.statusChange').change(function () {
                $currentStatus = $(this).val() ;
                $parentNode = $(this).parents('tbody tr');
                $userId = $parentNode.find('#userId').val();

                $data = {
                    'status' : $currentStatus ,
                    'userId' : $userId
                };

                $.ajax({
                    type : 'get' ,
                    url : '/user/change/status' ,
                    data : $data,
                    dataType : 'json'
                });

                location.reload();
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pizza_order_system\resources\views/admin/user/list.blade.php ENDPATH**/ ?>