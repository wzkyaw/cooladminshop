<?php $__env->startSection('title' , 'Admin List Page'); ?>

<?php $__env->startSection('content'); ?>
    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <div class="table-data__tool d-flex">
                        <div class="table-data__tool-left">
                            <div class="overview-wrap">
                                <h2 class="title-1">Admin Account List</h2>

                            </div>
                        </div>
                        
                        <div class="col-2">
                            <div style="background-color:rgba(47, 224, 44, 0.933);" class=" text-center py-1 rounded text-white"><i class="fa-solid fa-chart-simple"> - <?php echo e($admin->total()); ?></i></div>
                        </div>
                    </div>

                    
                    <div class="col-3 offset-9 bg-white rounded p-1">
                        <form action="<?php echo e(route('admin#list')); ?>" method="get" class="d-flex">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="searchKey" class="form-control" placeholder="Search..." value="<?php echo e(request('searchKey')); ?>">
                            <button type="submit" class="btn btn-dark text-white"><i class="fa-solid fa-magnifying-glass"></i></button>
                        </form>
                    </div>

                    
                    <?php if(session('createCategorySuccess')): ?>
                        <div class="col-6 offset-6 my-4">
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="fa-solid fa-check"></i>  <?php echo e(session('createCategorySuccess')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(session('deleteSuccess')): ?>
                        <div class="col-6 offset-6 my-4">
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <i class="fa-solid fa-check"></i>  <?php echo e(session('deleteSuccess')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(session('updateCategorySuccess')): ?>
                        <div class="col-6 offset-6 my-4">
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="fa-solid fa-check"></i>  <?php echo e(session('updateCategorySuccess')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                    <?php endif; ?>
                        <div class="table-responsive table-responsive-data2">
                            <table class="table table-data2">
                                <thead>
                                    <tr>
                                        <th>image</th>
                                        <th>name</th>
                                        <th>email</th>
                                        <th>phone</th>
                                        <th>gender</th>
                                        <th>address</th>
                                        <th>role</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="tr-shadow">
                                            <td class="col-1">
                                                <?php if($a->image == null): ?>
                                                    <?php if($a->gender == 'male'): ?>
                                                        <img src="<?php echo e(asset('image/default_user_profile.jpg')); ?>" class=" rounded-circle">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('image/female_default.png')); ?>" class=" rounded-circle">
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('storage/'.$a->image)); ?>" class="shadow-sm rounded-circle">
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($a->name); ?> <input type="hidden" id="userId" value="<?php echo e($a->id); ?>"></td>
                                            <td><?php echo e($a->email); ?></td>
                                            <td><?php echo e($a->phone); ?></td>
                                            <td><?php echo e($a->gender); ?></td>
                                            <td><?php echo e($a->address); ?></td>

                                            <td>
                                                <div class="table-data-feature">
                                                    <?php if(Auth::user()->id == $a->id): ?>
                                                    <?php else: ?>
                                                        <select name="roleStatus" id="changeStatus" class="me-5">
                                                            <option value="admin">Admin</option>
                                                            <option value="user">User</option>
                                                        </select>
                                                        <a href="<?php echo e(route('admin#changeRole' , $a->id)); ?>">
                                                            <button class="item me-1" data-toggle="tooltip" data-placement="top" title="Admin Change Role">
                                                                <i class="fa-solid fa-people-arrows"></i>
                                                            </button>
                                                        </a>
                                                        <a href="<?php echo e(route('admin#delete' , $a->id)); ?>" class="mr-1">
                                                            <button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                                <i class="fa-solid fa-trash"></i>
                                                            </button>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="mt-2 shadow pl-3">
                                <?php echo e($admin->links()); ?>

                                
                            </div>
                        </div>
                    <!-- END DATA TABLE -->
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptSource'); ?>
    <script>
        $(document).ready(function () {
            $('#changeStatus').change(function () {
                $currentStatus = $(this).val();
                $parentNodes = $(this).parents('tbody tr');
                $userId = $parentNodes.find('#userId').val();

                $data = {
                    'status' : $currentStatus ,
                    'userId' : $userId
                };

                $.ajax({
                    type : 'get' ,
                    url : '/admin/ajax/change/status' ,
                    data : $data,
                    dataType : 'json' ,
                });
                location.reload();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pizza_order_system\resources\views/admin/account/list.blade.php ENDPATH**/ ?>