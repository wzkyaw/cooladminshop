<?php $__env->startSection('title', 'Admin List Page'); ?>

<?php $__env->startSection('content'); ?>
    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="col-lg-10 offset-1">
                    
                    <button class="btn mb-3" style="background-color:rgba(47, 224, 44, 0.933); ">
                        <a class=" text-decoration-none text-white" href="<?php echo e(route('products#list')); ?>"><i class="fa-solid fa-circle-arrow-left me-2"></i>Back</a>
                    </button>
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title mt-3 mb-5">
                                <h3 class="text-center title-2">Pizzas Details...</h3>
                            </div>

                            <div class="row align-items-center mb-3">
                                <div class="col-3 offset-3 shadow-sm p-1 img-thumbnail object-cover text-center">
                                    <img src="<?php echo e(asset('storage/'.$pizzas->image)); ?>" alt="John Doe" />
                                </div>
                                <div class="col-5 ms-4">
                                    <span class="my-2 d-block"><i class="fa-solid me-2 fa-passport"></i>Category - <?php echo e($pizzas->category_name); ?></span>
                                    <span class="my-2 d-block"><i class="fa-solid me-2 fa-pizza-slice"></i><?php echo e($pizzas->name); ?></span>
                                    <span class="my-2 d-block"><i class="fa-solid me-2 fa-circle-info"></i><?php echo e($pizzas->description); ?></span>
                                    <span class="my-2 d-block"><i class="fa-solid me-2 fa-clock"></i>about - <?php echo e($pizzas->waiting_time); ?> minutes!</span>
                                    <span class="my-2 d-block"><i class="fa-solid me-2 fa-hand-holding-dollar"></i><?php echo e($pizzas->price); ?> Kyats!</span>
                                </div>
                            </div>

                            

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pizza_order_system\resources\views/admin/product/details.blade.php ENDPATH**/ ?>