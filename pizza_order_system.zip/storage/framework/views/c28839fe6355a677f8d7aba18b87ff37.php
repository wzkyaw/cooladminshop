<?php $__env->startSection('content'); ?>
    <div class="container mt-5 text-center">
        <h1>User Home Page</h1>

        <strong>Role - <?php echo e(Auth::user()->role); ?></strong>

        <form action="<?php echo e(route('logout')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="submit" value="Log Out" class="btn btn-danger mt-2">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pizza_order_system\resources\views/user/home.blade.php ENDPATH**/ ?>